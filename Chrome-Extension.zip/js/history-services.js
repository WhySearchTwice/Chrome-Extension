angular.module('history.services', []).
value('version', '0.1');