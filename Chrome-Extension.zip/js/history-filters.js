angular.module('history.filters', [])
    .filter('interpolate', [])
;
